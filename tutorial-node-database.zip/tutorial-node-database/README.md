# node-js-database
Setting up a MySQL database with Node.js
